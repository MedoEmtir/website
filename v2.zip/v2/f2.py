from flask import Flask , render_template

mine = Flask(__name__)
@mine.route("/")
def home():
    return render_template('main.html')
if __name__ == "__main__":
    mine.run()